import { TEditorConfiguration } from '../../documents/editor/core';
declare const EMPTY_EMAIL_MESSAGE: TEditorConfiguration;
export default EMPTY_EMAIL_MESSAGE;
//# sourceMappingURL=empty-email-message.d.ts.map