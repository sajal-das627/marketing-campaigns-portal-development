import { TEditorConfiguration } from '../../documents/editor/core';
declare const WELCOME: TEditorConfiguration;
export default WELCOME;
//# sourceMappingURL=welcome.d.ts.map