import { TEditorConfiguration } from '../../documents/editor/core';
declare const POST_METRICS_REPORT: TEditorConfiguration;
export default POST_METRICS_REPORT;
//# sourceMappingURL=post-metrics-report.d.ts.map