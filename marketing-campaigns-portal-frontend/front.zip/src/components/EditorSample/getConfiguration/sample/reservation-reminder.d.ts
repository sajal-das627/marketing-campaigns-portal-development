import { TEditorConfiguration } from '../../documents/editor/core';
declare const RESERVATION_REMINDER: TEditorConfiguration;
export default RESERVATION_REMINDER;
//# sourceMappingURL=reservation-reminder.d.ts.map