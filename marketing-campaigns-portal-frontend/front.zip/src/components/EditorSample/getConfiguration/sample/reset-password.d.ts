import { TEditorConfiguration } from '../../documents/editor/core';
declare const RESET_PASSWORD: TEditorConfiguration;
export default RESET_PASSWORD;
//# sourceMappingURL=reset-password.d.ts.map