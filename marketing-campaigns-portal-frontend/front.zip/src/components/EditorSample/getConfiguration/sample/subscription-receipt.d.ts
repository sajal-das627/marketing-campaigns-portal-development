import { TEditorConfiguration } from '../../documents/editor/core';
declare const SUBSCRIPTION_RECEIPT: TEditorConfiguration;
export default SUBSCRIPTION_RECEIPT;
//# sourceMappingURL=subscription-receipt.d.ts.map