import { TEditorConfiguration } from '../../documents/editor/core';
declare const RESPOND_TO_MESSAGE: TEditorConfiguration;
export default RESPOND_TO_MESSAGE;
//# sourceMappingURL=respond-to-message.d.ts.map