import { TEditorConfiguration } from '../../documents/editor/core';
declare const ONE_TIME_PASSCODE: TEditorConfiguration;
export default ONE_TIME_PASSCODE;
//# sourceMappingURL=one-time-passcode.d.ts.map