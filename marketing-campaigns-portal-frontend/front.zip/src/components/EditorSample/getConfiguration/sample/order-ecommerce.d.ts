import { TEditorConfiguration } from '../../documents/editor/core';
declare const ORDER_ECOMMERCE: TEditorConfiguration;
export default ORDER_ECOMMERCE;
//# sourceMappingURL=order-ecommerce.d.ts.map