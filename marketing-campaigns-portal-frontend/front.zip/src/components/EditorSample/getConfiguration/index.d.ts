export default function getConfiguration(template: string): any;
//# sourceMappingURL=index.d.ts.map