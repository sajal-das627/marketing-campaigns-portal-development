export default function App(): any;
//# sourceMappingURL=index.d.ts.map