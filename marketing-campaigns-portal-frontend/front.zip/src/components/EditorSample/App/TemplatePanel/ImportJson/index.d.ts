export default function ImportJson(): any;
//# sourceMappingURL=index.d.ts.map