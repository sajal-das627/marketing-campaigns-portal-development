type ImportJsonDialogProps = {
    onClose: () => void;
};
export default function ImportJsonDialog({ onClose }: ImportJsonDialogProps): any;
export {};
//# sourceMappingURL=ImportJsonDialog.d.ts.map