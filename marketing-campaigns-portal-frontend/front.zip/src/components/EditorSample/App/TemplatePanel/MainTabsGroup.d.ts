export default function MainTabsGroup(): any;
//# sourceMappingURL=MainTabsGroup.d.ts.map