export default function ShareButton(): any;
//# sourceMappingURL=ShareButton.d.ts.map