export declare function html(value: string): Promise<string>;
export declare function json(value: string): Promise<string>;
//# sourceMappingURL=highlighters.d.ts.map