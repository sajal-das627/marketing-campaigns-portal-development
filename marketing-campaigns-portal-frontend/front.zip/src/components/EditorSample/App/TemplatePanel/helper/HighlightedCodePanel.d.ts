type TextEditorPanelProps = {
    type: 'json' | 'html' | 'javascript';
    value: string;
};
export default function HighlightedCodePanel({ type, value }: TextEditorPanelProps): any;
export {};
//# sourceMappingURL=HighlightedCodePanel.d.ts.map