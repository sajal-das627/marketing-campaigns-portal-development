export default function DownloadJson(): any;
//# sourceMappingURL=index.d.ts.map