export default function JsonPanel(): any;
//# sourceMappingURL=JsonPanel.d.ts.map