export default function HtmlPanel(): any;
//# sourceMappingURL=HtmlPanel.d.ts.map