import { ContainerProps } from '../../../../documents/blocks/Container/ContainerPropsSchema';
type ContainerSidebarPanelProps = {
    data: ContainerProps;
    setData: (v: ContainerProps) => void;
};
export default function ContainerSidebarPanel({ data, setData }: ContainerSidebarPanelProps): any;
export {};
//# sourceMappingURL=ContainerSidebarPanel.d.ts.map