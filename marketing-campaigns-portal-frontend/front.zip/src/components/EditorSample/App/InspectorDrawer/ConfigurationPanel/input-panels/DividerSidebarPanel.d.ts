import { DividerProps } from '@usewaypoint/block-divider';
type DividerSidebarPanelProps = {
    data: DividerProps;
    setData: (v: DividerProps) => void;
};
export default function DividerSidebarPanel({ data, setData }: DividerSidebarPanelProps): any;
export {};
//# sourceMappingURL=DividerSidebarPanel.d.ts.map