import { ColumnsContainerProps } from '../../../../documents/blocks/ColumnsContainer/ColumnsContainerPropsSchema';
type ColumnsContainerPanelProps = {
    data: ColumnsContainerProps;
    setData: (v: ColumnsContainerProps) => void;
};
export default function ColumnsContainerPanel({ data, setData }: ColumnsContainerPanelProps): any;
export {};
//# sourceMappingURL=ColumnsContainerSidebarPanel.d.ts.map