
import React, { useState } from 'react';
import { InputLabel, Stack } from '@mui/material';
import RawSliderInput from './raw/RawSliderInput';

var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
export default function SliderInput(_a) {
    var { label, defaultValue, onChange } = _a, props = __rest(_a, ["label", "defaultValue", "onChange"]);
    const [value, setValue] = useState(defaultValue);
    return (React.createElement(Stack, { spacing: 1, alignItems: "flex-start" },
        React.createElement(InputLabel, { shrink: true }, label),
        React.createElement(RawSliderInput, Object.assign({ value: value, setValue: (value) => {
                setValue(value);
                onChange(value);
            } }, props))));
}
//# sourceMappingURL=SliderInput.js.map