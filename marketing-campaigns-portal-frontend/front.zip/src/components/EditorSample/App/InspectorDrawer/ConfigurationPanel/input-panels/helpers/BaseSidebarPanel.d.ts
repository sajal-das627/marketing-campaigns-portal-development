import React from 'react';
type SidebarPanelProps = {
    title: string;
    children: React.ReactNode;
};
export default function BaseSidebarPanel({ title, children }: SidebarPanelProps): any;
export {};
//# sourceMappingURL=BaseSidebarPanel.d.ts.map