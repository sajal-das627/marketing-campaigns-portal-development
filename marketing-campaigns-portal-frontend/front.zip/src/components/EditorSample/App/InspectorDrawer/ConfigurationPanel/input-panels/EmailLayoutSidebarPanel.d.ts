import { EmailLayoutProps } from '../../../../documents/blocks/EmailLayout/EmailLayoutPropsSchema';
type EmailLayoutSidebarFieldsProps = {
    data: EmailLayoutProps;
    setData: (v: EmailLayoutProps) => void;
};
export default function EmailLayoutSidebarFields({ data, setData }: EmailLayoutSidebarFieldsProps): any;
export {};
//# sourceMappingURL=EmailLayoutSidebarPanel.d.ts.map