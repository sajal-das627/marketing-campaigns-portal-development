import { HtmlProps } from '@usewaypoint/block-html';
type HtmlSidebarPanelProps = {
    data: HtmlProps;
    setData: (v: HtmlProps) => void;
};
export default function HtmlSidebarPanel({ data, setData }: HtmlSidebarPanelProps): any;
export {};
//# sourceMappingURL=HtmlSidebarPanel.d.ts.map