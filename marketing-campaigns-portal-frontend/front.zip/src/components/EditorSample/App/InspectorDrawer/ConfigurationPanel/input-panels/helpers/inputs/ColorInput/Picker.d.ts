type Props = {
    value: string;
    onChange: (v: string) => void;
};
export default function Picker({ value, onChange }: Props): any;
export {};
//# sourceMappingURL=Picker.d.ts.map