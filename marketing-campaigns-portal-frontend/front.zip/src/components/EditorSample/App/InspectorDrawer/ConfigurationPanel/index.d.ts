export default function ConfigurationPanel(): any;
//# sourceMappingURL=index.d.ts.map