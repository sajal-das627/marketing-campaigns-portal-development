import { ButtonProps } from '@usewaypoint/block-button';
type ButtonSidebarPanelProps = {
    data: ButtonProps;
    setData: (v: ButtonProps) => void;
};
export default function ButtonSidebarPanel({ data, setData }: ButtonSidebarPanelProps): any;
export {};
//# sourceMappingURL=ButtonSidebarPanel.d.ts.map