import { ImageProps } from '@usewaypoint/block-image';
type ImageSidebarPanelProps = {
    data: ImageProps;
    setData: (v: ImageProps) => void;
};
export default function ImageSidebarPanel({ data, setData }: ImageSidebarPanelProps): any;
export {};
//# sourceMappingURL=ImageSidebarPanel.d.ts.map