import { AvatarProps } from '@usewaypoint/block-avatar';
type AvatarSidebarPanelProps = {
    data: AvatarProps;
    setData: (v: AvatarProps) => void;
};
export default function AvatarSidebarPanel({ data, setData }: AvatarSidebarPanelProps): any;
export {};
//# sourceMappingURL=AvatarSidebarPanel.d.ts.map