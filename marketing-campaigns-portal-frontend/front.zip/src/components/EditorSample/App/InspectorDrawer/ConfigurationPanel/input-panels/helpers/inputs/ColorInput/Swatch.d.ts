type Props = {
    paletteColors: string[];
    value: string;
    onChange: (value: string) => void;
};
export default function Swatch({ paletteColors, value, onChange }: Props): any;
export {};
//# sourceMappingURL=Swatch.d.ts.map