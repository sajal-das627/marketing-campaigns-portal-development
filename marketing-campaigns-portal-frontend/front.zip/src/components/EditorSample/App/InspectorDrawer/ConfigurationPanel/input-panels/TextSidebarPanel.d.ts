import { TextProps } from '@usewaypoint/block-text';
type TextSidebarPanelProps = {
    data: TextProps;
    setData: (v: TextProps) => void;
};
export default function TextSidebarPanel({ data, setData }: TextSidebarPanelProps): any;
export {};
//# sourceMappingURL=TextSidebarPanel.d.ts.map