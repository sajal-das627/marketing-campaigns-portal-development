import { SpacerProps } from '@usewaypoint/block-spacer';
type SpacerSidebarPanelProps = {
    data: SpacerProps;
    setData: (v: SpacerProps) => void;
};
export default function SpacerSidebarPanel({ data, setData }: SpacerSidebarPanelProps): any;
export {};
//# sourceMappingURL=SpacerSidebarPanel.d.ts.map