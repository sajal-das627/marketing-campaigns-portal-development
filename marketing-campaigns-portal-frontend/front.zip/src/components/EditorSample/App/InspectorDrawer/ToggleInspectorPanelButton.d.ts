export default function ToggleInspectorPanelButton(): any;
//# sourceMappingURL=ToggleInspectorPanelButton.d.ts.map