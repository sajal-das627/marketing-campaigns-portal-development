export declare const INSPECTOR_DRAWER_WIDTH = 320;
export default function InspectorDrawer(): any;
//# sourceMappingURL=index.d.ts.map