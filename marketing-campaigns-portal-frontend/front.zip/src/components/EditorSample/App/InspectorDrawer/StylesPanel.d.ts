export default function StylesPanel(): any;
//# sourceMappingURL=StylesPanel.d.ts.map