export declare const SAMPLES_DRAWER_WIDTH = 240;
export default function SamplesDrawer(): any;
//# sourceMappingURL=index.d.ts.map