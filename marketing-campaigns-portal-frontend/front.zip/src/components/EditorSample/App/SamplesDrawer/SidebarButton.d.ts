import React from 'react';

export default function SidebarButton({ href, children }: {
    href: string;
    children: React.ReactNode | string;
    // children: React.ReactNode | JSX.Element | string;
}): any;
//# sourceMappingURL=SidebarButton.d.ts.map