export default function ToggleSamplesPanelButton(): any;
//# sourceMappingURL=ToggleSamplesPanelButton.d.ts.map