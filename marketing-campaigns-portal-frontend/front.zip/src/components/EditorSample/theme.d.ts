declare const THEME: any;
export default THEME;
//# sourceMappingURL=theme.d.ts.map