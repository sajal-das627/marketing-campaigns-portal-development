import { z } from 'zod';
declare const EmailLayoutPropsSchema: any;
export default EmailLayoutPropsSchema;
export type EmailLayoutProps = z.infer<typeof EmailLayoutPropsSchema>;
//# sourceMappingURL=EmailLayoutPropsSchema.d.ts.map