import { EmailLayoutProps } from './EmailLayoutPropsSchema';
export default function EmailLayoutEditor(props: EmailLayoutProps): any;
//# sourceMappingURL=EmailLayoutEditor.d.ts.map