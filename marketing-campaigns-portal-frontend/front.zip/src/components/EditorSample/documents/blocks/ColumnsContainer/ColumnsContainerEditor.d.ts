import { ColumnsContainerProps } from './ColumnsContainerPropsSchema';
export default function ColumnsContainerEditor({ style, props }: ColumnsContainerProps): any;
//# sourceMappingURL=ColumnsContainerEditor.d.ts.map