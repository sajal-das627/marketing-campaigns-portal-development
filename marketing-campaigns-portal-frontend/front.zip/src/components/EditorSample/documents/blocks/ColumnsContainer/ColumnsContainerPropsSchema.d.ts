import { z } from 'zod';
declare const ColumnsContainerPropsSchema: any;
export type ColumnsContainerProps = z.infer<typeof ColumnsContainerPropsSchema>;
export default ColumnsContainerPropsSchema;
//# sourceMappingURL=ColumnsContainerPropsSchema.d.ts.map