import { z } from 'zod';
declare const ContainerPropsSchema: any;
export default ContainerPropsSchema;
export type ContainerProps = z.infer<typeof ContainerPropsSchema>;
//# sourceMappingURL=ContainerPropsSchema.d.ts.map