import { ContainerProps } from './ContainerPropsSchema';
export default function ContainerEditor({ style, props }: ContainerProps): any;
//# sourceMappingURL=ContainerEditor.d.ts.map