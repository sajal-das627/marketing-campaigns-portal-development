/* eslint-disable @typescript-eslint/no-explicit-any */

export type TStyle = {
  backgroundColor?: any;
  borderColor?: any;
  borderRadius?: any;
  color?: any;
  fontFamily?: any;
  fontSize?: any;
  fontWeight?: any;
  padding?: any;
  textAlign?: any;
};
