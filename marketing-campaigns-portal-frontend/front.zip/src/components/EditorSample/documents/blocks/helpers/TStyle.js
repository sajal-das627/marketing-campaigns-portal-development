/* eslint-disable @typescript-eslint/no-explicit-any */
export {};
//# sourceMappingURL=TStyle.js.map