type TEditorBlockWrapperProps = {
    children: React.ReactNode;
    // children: JSX.Element;
};
export default function EditorBlockWrapper({ children }: TEditorBlockWrapperProps): any;
export {};
//# sourceMappingURL=EditorBlockWrapper.d.ts.map