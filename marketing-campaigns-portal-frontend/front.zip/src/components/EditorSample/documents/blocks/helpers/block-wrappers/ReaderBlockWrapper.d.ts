import { TStyle } from '../TStyle';
type TReaderBlockWrapperProps = {
    style: TStyle;
    children: React.ReactNode;
    // children: JSX.Element;
};
export default function ReaderBlockWrapper({ style, children }: TReaderBlockWrapperProps): any;
export {};
//# sourceMappingURL=ReaderBlockWrapper.d.ts.map