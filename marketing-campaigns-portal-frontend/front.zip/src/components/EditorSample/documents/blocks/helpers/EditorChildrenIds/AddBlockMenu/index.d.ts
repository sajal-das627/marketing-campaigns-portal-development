import { TEditorBlock } from '../../../../editor/core';
type Props = {
    placeholder?: boolean;
    onSelect: (block: TEditorBlock) => void;
};
export default function AddBlockButton({ onSelect, placeholder }: Props): any;
export {};
//# sourceMappingURL=index.d.ts.map