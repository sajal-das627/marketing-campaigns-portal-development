export type TStyle = {
    backgroundColor?: any;
    borderColor?: any;
    borderRadius?: any;
    color?: any;
    fontFamily?: any;
    fontSize?: any;
    fontWeight?: any;
    padding?: any;
    textAlign?: any;
};
//# sourceMappingURL=TStyle.d.ts.map