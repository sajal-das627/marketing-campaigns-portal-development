export declare function zColor(): any;
export declare function zFontFamily(): any;
export declare function zFontWeight(): any;
export declare function zTextAlign(): any;
export declare function zPadding(): any;
//# sourceMappingURL=zod.d.ts.map