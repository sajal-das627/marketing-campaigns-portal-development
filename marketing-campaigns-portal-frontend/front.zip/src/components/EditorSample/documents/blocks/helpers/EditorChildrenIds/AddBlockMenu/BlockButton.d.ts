import React from 'react';
type BlockMenuButtonProps = {
    label: string;
    icon: React.ReactNode;
    onClick: () => void;
};
export default function BlockTypeButton({ label, icon, onClick }: BlockMenuButtonProps): any;
export {};
//# sourceMappingURL=BlockButton.d.ts.map