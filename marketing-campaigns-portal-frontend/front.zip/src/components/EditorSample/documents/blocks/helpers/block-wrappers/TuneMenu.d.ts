type Props = {
    blockId: string;
};
export default function TuneMenu({ blockId }: Props): any;
export {};
//# sourceMappingURL=TuneMenu.d.ts.map