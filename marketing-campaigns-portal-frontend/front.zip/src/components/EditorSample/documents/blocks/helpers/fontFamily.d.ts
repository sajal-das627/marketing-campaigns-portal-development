export declare const FONT_FAMILIES: {};
export declare const FONT_FAMILY_NAMES: readonly ["MODERN_SANS", "BOOK_SANS", "ORGANIC_SANS", "GEOMETRIC_SANS", "HEAVY_SANS", "ROUNDED_SANS", "MODERN_SERIF", "BOOK_SERIF", "MONOSPACE"];
//# sourceMappingURL=fontFamily.d.ts.map