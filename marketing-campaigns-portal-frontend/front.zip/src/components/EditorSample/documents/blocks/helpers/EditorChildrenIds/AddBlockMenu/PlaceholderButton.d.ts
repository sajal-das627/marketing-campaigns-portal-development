type Props = {
    onClick: () => void;
};
export default function PlaceholderButton({ onClick }: Props): any;
export {};
//# sourceMappingURL=PlaceholderButton.d.ts.map