type Props = {
    buttonElement: HTMLElement | null;
    onClick: () => void;
};
export default function DividerButton({ buttonElement, onClick }: Props): any;
export {};
//# sourceMappingURL=DividerButton.d.ts.map